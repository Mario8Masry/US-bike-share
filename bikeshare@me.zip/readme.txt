Sites and sources:
1-Figstack
2-Sttack over flow 
3-Jupyter notebook
4-Youtube